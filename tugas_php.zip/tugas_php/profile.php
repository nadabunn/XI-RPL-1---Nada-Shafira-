<!DOCTYPE html>
<html>
<head>
    <title>My Lil Profile</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #e0e0e0; /* Warna latar belakang halaman */
        }
        .profile-container {
            background-color: #ffffff; /* Warna latar belakang kotak profil */
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Bayangan di sekitar kotak */
            width: 350px; /* Lebar kotak */
            text-align: center;
            border: 1px solid #ddd; /* Batas halus di sekitar kotak */
        }
        .profile-container img {
            border-radius: 50%; /* Membuat foto profil berbentuk lingkaran */
            width: 120px;
            height: 120px;
            object-fit: cover; /* Memastikan gambar tidak terdistorsi */
            margin-bottom: 20px;
        }
        .profile-container h1 {
            margin: 10px 0;
            color: #333; /* Warna teks */
        }
        .profile-container p {
            color: #666; /* Warna teks deskripsi */
            font-size: 16px;
            line-height: 1.5; /* Jarak antar baris */
        }
        .profile-container .contact-info {
            margin: 20px 0;
            font-size: 14px;
            color: #444;
        }
        .profile-container .contact-info a {
            color: #3498db; /* Warna link */
            text-decoration: none;
        }
        .profile-container .contact-info a:hover {
            text-decoration: underline; /* Garis bawah saat hover */
        }
        .profile-container button {
            background-color: maroon; /* Warna latar belakang tombol */
            color: #ffffff; /* Warna teks tombol */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .profile-container button:hover {
            background-color: maroon; /* Warna latar belakang tombol saat hover */
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <?php
        // Data profil pengguna
        $name = "Nada Kim";
        $description = "Im a student exchange from US. I love being here, my fav to do is walk in Gasibu. Actually i live in beautiful London";
        $profilePic = "flash.jpg"; // Ganti dengan URL foto profil
        $email = "kim@gmail.com";
        $phone = "+138720319455";

        // Menampilkan profil
        echo '<img src="' . htmlspecialchars($profilePic) . '" alt="Foto Profil">';
        echo '<h1>' . htmlspecialchars($name) . '</h1>';
        echo '<p>' . htmlspecialchars($description) . '</p>';
        ?>
        <div class="contact-info">
            <p>Email: <a href="mailto:<?php echo htmlspecialchars($email); ?>"><?php echo htmlspecialchars($email); ?></a></p>
            <p>Phone: <a href="tel:<?php echo htmlspecialchars($phone); ?>"><?php echo htmlspecialchars($phone); ?></a></p>
        </div>
        <button>Hubungi Saya</button>
    </div>
</body>
</html>
